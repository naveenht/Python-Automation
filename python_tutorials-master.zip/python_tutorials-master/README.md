Python basics and code snippets
