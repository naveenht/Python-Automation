class Config:
    URL = 'http://demowebshop.tricentis.com/'
    BROWSER_NAME = "chrome"
    USERNAME = ""
    PASSWORD = ""
    FIREFOX_DRIVER_PATH = r""
    GECKO_DRIVER_PATH = r""
    CHROME_DRIVER_PATH = "/Users/sandeep/Documents/Python_Selenium_FW/Library/chromedriver"
    IE_DRIVER_PATH = r""
    DATA_FILE_PATH = "/Users/sandeep/Documents/Python_Selenium_FW/Data/TestData.xlsx"
    OBJECTS_FILE_PATH = "/Users/sandeep/Documents/Python_Selenium_FW/Data/Objects.xlsx"
